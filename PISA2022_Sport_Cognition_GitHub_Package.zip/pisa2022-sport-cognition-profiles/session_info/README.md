# Session information

Run:

```r
source("code/99_session_info.R")
```

from the project root after loading the environment used for the final manuscript analyses.

Commit the resulting `sessionInfo.txt` before public release.

For stronger package-version reproducibility, consider using `renv` and committing an `renv.lock` file.
