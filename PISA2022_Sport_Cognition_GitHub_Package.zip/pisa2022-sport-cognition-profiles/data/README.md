# Data

## Original source data

The original microdata are **not included** in this repository.

Download PISA 2022 public-use files directly from the OECD:

https://www.oecd.org/en/data/datasets/pisa-2022-database.html

The study uses information from:

- Student Questionnaire data;
- School Questionnaire data;
- Well-being Questionnaire variables;
- Creative Thinking cognitive data;
- mathematics and reading plausible values;
- final student weights and 80 Fay-BRR replicate weights.

## Derived/processed materials

If the final analysis created an analysis-ready dataset that can be redistributed consistently with OECD terms, place it in a `processed/` subfolder and document:

- filename;
- unit of analysis;
- number of rows and columns;
- education systems included;
- variables retained;
- transformations;
- missing-data restrictions;
- whether identifiers have been removed or transformed.

If redistribution is uncertain, do **not** upload the derived microdata. Instead, provide the actual preprocessing code so users can reconstruct the analysis dataset from the OECD source files.

## Documentation

- `data_dictionary.csv` documents the core source and derived variables.
- `analysis_sample_summary.csv` records the main analytical sample sizes reported in the manuscript.
