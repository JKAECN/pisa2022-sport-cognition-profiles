# PISA 2022 Sport–Cognition Profiles: Reproducibility Materials

This repository contains reproducibility materials for the manuscript:

**Cognitive Association Profiles of School Sport, Physical Education, and Physical Activity across Creative Thinking, Mathematics, and Reading in PISA 2022**

Authors: Liuzhong Sun, Huina Li, Jinkai Zhang, and Gina S. Rhee

## Repository purpose

The study uses public-use PISA 2022 data to examine whether different sporting experiences—school sports provision, physical education (PE) frequency, moderate-intensity activity, and vigorous-intensity activity—show distinct association profiles across creative thinking, mathematics, and reading.

The repository is intended to document the analytical workflow, derived variables, analysis outputs, and sensitivity checks used in the manuscript. It does **not** redistribute the original OECD PISA microdata.

## Source data

The original PISA 2022 public-use datasets are available from the OECD:

https://www.oecd.org/en/data/datasets/pisa-2022-database.html

The analysis draws on variables from the Student Questionnaire, School Questionnaire, Well-being Questionnaire, and Creative Thinking cognitive data.

Because the original microdata are maintained and distributed by the OECD, users should download the source files directly from the OECD website. The files in this repository document the transformations and derived outputs used in the study.

## Recommended repository title

**PISA 2022 Sport–Cognition Profiles: Reproducibility Materials**

Suggested repository slug:

`pisa2022-sport-cognition-profiles`

Suggested GitHub description:

> Reproducibility materials for a cross-system PISA 2022 study of school sport, PE frequency, moderate- and vigorous-intensity activity, and cognitive association profiles across creative thinking, mathematics, and reading.

Suggested topics:

`pisa-2022`, `creative-thinking`, `physical-activity`, `physical-education`, `reproducible-research`, `r`, `plausible-values`, `fay-brr`, `meta-analysis`, `education`

## Repository structure

```text
pisa2022-sport-cognition-profiles/
├── README.md
├── CITATION.cff
├── .gitignore
├── code/
│   ├── 06_grade_programme_sensitivity.R
│   ├── 99_session_info.R
│   └── README.md
├── data/
│   ├── README.md
│   ├── data_dictionary.csv
│   └── analysis_sample_summary.csv
├── results/
│   ├── tables/
│   │   ├── Table_01.csv
│   │   └── ...
│   ├── figures/
│   │   ├── Figure_01.png
│   │   └── ...
│   └── sensitivity/
│       ├── S5_01_grade_programme_availability.csv
│       ├── S5_02_PE_pathway_system_estimates.csv
│       ├── S5_03_PE_pathway_meta.csv
│       └── S5_04_PE_pathway_same_sample_comparison.csv
├── docs/
│   ├── DATA_AVAILABILITY_STATEMENT.txt
│   ├── GITHUB_REPOSITORY_INFO.txt
│   ├── REPRODUCIBILITY_CHECKLIST.md
│   └── FILE_MANIFEST.csv
└── session_info/
    └── README.md
```

## What is included now

This package contains:

- the grade/programme-pathway sensitivity analysis script currently available for the project;
- all four derived sensitivity-analysis output files;
- CSV exports of the nine manuscript tables;
- the four manuscript figures;
- a variable/data dictionary;
- a summary of analytical sample sizes;
- a reproducibility checklist;
- a Data Availability Statement ready to paste into the manuscript after adding the final GitHub URL.

## What still needs to be added from the local analysis folder

Before making the repository public, add the **actual R scripts used for the main analyses**. Do not replace them with reconstructed or approximate code. The recommended naming/order is:

1. `00_import_merge_pisa2022.R`
2. `01_construct_variables_samples.R`
3. `02_main_separate_models.R`
4. `03_common_sample_joint_models.R`
5. `04_domain_profile_contrasts.R`
6. `05_school_provision_models.R`
7. `06_grade_programme_sensitivity.R`  *(already included here)*
8. `07_meta_analysis_tables_figures.R`
9. `99_session_info.R`

If your existing scripts use different filenames, keep the original filenames and document the run order in `code/README.md`.

If you created an analysis-ready dataset during preprocessing and its redistribution is compatible with OECD terms, add it under `data/processed/` together with a codebook. Otherwise, keep the source data external and provide code that reconstructs the analysis-ready data from the OECD files.

## Reproduction logic

A complete reproduction should follow this order:

1. Download the required PISA 2022 public-use source files from OECD.
2. Place them in a local folder outside version control.
3. Run the import/merge script.
4. Construct derived sport indicators, standardized cognitive variables, covariates, common samples, and pathway variables.
5. Fit system-specific models using 10 plausible values, the final student weight, and 80 Fay-BRR replicate weights.
6. Pool plausible-value uncertainty.
7. Synthesize system estimates using REML random-effects models with Hartung–Knapp uncertainty.
8. Run common-sample, domain-profile, school-provision, and pathway sensitivity analyses.
9. Generate the tables and figures reported in the manuscript.
10. Save `sessionInfo()` output.

## Data-sharing boundary

The repository should not be described as hosting the original PISA 2022 data. The preferred formulation is:

- **OECD** hosts the original public-use PISA 2022 microdata.
- **This repository** hosts the authors' analysis code, data-processing documentation, derived analysis outputs, and—if legally appropriate—the minimal analysis-ready derived data needed for reproduction.

## Data Availability Statement

See `docs/DATA_AVAILABILITY_STATEMENT.txt`.

After you create the GitHub repository, replace:

`[INSERT_GITHUB_REPOSITORY_URL]`

with the public repository URL.

## Citation

Please cite the associated article once published. Repository citation metadata are provided in `CITATION.cff`.

## Reproducibility note

This repository is intended to document the final analysis used for publication. Any code file added before public release should be the actual script used to generate the reported results, not a reconstructed approximation.
