# Reproducibility checklist before making the repository public

## Essential items

- [ ] Copy the **actual main-analysis R scripts** from the computer used for the final analyses.
- [ ] Confirm that no script contains private absolute paths (for example `E:/...`).
- [ ] Confirm that all analysis parameters in the public code match the manuscript.
- [ ] Confirm that the 10 plausible values, W_FSTUWT, and all 80 Fay-BRR replicate weights are handled exactly as in the final analysis.
- [ ] Confirm the Fay coefficient (rho = .50).
- [ ] Confirm the common-sample rule that yields N = 99,921 students in 4,402 schools.
- [ ] Confirm the 13-system main analysis set and 10-system school-provision set.
- [ ] Confirm grade sensitivity (13 systems) and programme-pathway sensitivity (12 systems).
- [ ] Save `sessionInfo()` output.
- [ ] Consider adding `renv.lock` for package-version reproducibility.
- [ ] Confirm that all table CSVs match the final manuscript.
- [ ] Confirm that all figure files match the final manuscript.
- [ ] Replace `[INSERT_GITHUB_REPOSITORY_URL]` in the Data Availability Statement.
- [ ] Add the final repository URL to the manuscript.
- [ ] If using a DOI-backed archive (recommended), create a versioned release and archive it (for example with Zenodo), then add the DOI.

## Data-sharing checks

- [ ] Do not redistribute OECD source microdata unless redistribution terms clearly allow it.
- [ ] If sharing an analysis-ready derived microdataset, verify that doing so complies with the source-data terms.
- [ ] Remove any unnecessary direct identifiers from derived files.
- [ ] Provide a codebook for every shared analysis-ready dataset.
- [ ] Document all exclusions, transformations, standardizations, and recodes.

## Manuscript consistency checks

- [ ] Repository title matches the manuscript title/project.
- [ ] Sample sizes match Table 2.
- [ ] Table 5 common-sample coefficients match the final analysis.
- [ ] Table 6 Moderate−Vigorous contrasts match the final analysis.
- [ ] Table 7 domain-profile contrasts match the final analysis.
- [ ] Table 9 pathway sensitivity estimates match the final analysis.
