# Code

This folder should contain the **actual R scripts used for the published analyses**.

## Included

- `06_grade_programme_sensitivity.R` — grade and ISCED programme-pathway sensitivity analysis.
- `99_session_info.R` — saves the final R session/package information.

## Main-analysis scripts still to add

Please copy the original scripts from the analysis computer into this repository before making it public. A recommended run order is:

1. data import and file merging;
2. variable construction and sample definition;
3. separate sport-indicator models;
4. exact common-sample and joint models;
5. CT–Math / CT–Reading domain-profile contrasts;
6. supplementary school-provision models;
7. grade/programme-pathway sensitivity analysis;
8. meta-analysis, tables, and figures;
9. `sessionInfo()` export.

Keep the real filenames if they already exist. The public repository should reflect the analysis that actually produced the paper rather than reconstructed code.

## Raw-data paths

Do not hard-code personal local paths such as `E:/...` in the public scripts. Use a project-level configuration such as:

```r
RAW_DIR <- Sys.getenv("PISA2022_RAW_DIR")
OUT_DIR <- "results"
```

and document the expected source files in `data/README.md`.
