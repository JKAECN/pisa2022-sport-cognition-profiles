# ============================================================
# R5A PE GRADE / PROGRAMME-PATH SENSITIVITY
#
# PURPOSE:
#   Test whether the PE-days coefficient is sensitive to
#   (1) grade placement and
#   (2) programme pathway.
#
# DESIGN:
#   Grade and programme are fitted SEPARATELY.
#   Each adjustment uses its own exact complete-case sample:
#
#   Grade:
#       same-sample baseline
#       -> grade-adjusted
#
#   Programme:
#       same-sample baseline
#       -> programme-adjusted
#
#   This avoids structural collinearity between GRADE_PATH and
#   PROGRAM_PATH (confirmed for MEX).
# ============================================================

cat(
  "\n============================================================\n",
  "R5A PE GRADE / PROGRAMME-PATH SENSITIVITY\n",
  "============================================================\n",
  sep = ""
)

# ------------------------------------------------------------
# 0. Containers
# ------------------------------------------------------------

pathway_availability_rows <- list()
pathway_system_rows <- list()

# ------------------------------------------------------------
# 1. Helper:
# Convert labelled variables to character without imposing
# an artificial ordering.
# ------------------------------------------------------------

to_factor_character <- function(x) {

  if (inherits(x, "haven_labelled")) {

    as.character(
      haven::as_factor(
        x,
        levels = "values"
      )
    )

  } else {

    as.character(x)
  }
}

# ------------------------------------------------------------
# 2. Identify available programme variables
# ------------------------------------------------------------

if (!exists("preferred_program_vars")) {

  preferred_program_vars <- intersect(
    c("ISCEDP"),
    names(path_raw)
  )
}

found_path_vars <- character(0)

if ("GRADE" %in% names(path_raw)) {
  found_path_vars <- c(
    found_path_vars,
    "GRADE"
  )
}

if (length(preferred_program_vars) > 0) {
  found_path_vars <- c(
    found_path_vars,
    preferred_program_vars
  )
}

cat(
  "Pathway variables found: ",
  paste(
    found_path_vars,
    collapse = ", "
  ),
  "\n",
  sep = ""
)

# ------------------------------------------------------------
# 3. Construct GRADE_PATH
# ------------------------------------------------------------

if ("GRADE" %in% names(path_raw)) {

  path_raw$GRADE_PATH <- to_factor_character(
    path_raw$GRADE
  )
}

# ------------------------------------------------------------
# 4. Construct PROGRAM_PATH
# ------------------------------------------------------------

if (length(preferred_program_vars) == 1) {

  program_var <- preferred_program_vars[1]

  path_raw$PROGRAM_PATH <- to_factor_character(
    path_raw[[program_var]]
  )

} else if (length(preferred_program_vars) > 1) {

  tmp <- lapply(
    preferred_program_vars,
    function(v) {
      to_factor_character(
        path_raw[[v]]
      )
    }
  )

  path_raw$PROGRAM_PATH <- do.call(
    paste,
    c(
      tmp,
      sep = "|"
    )
  )

  all_missing <- Reduce(
    "&",
    lapply(
      tmp,
      function(x) {
        is.na(x) | x == ""
      }
    )
  )

  path_raw$PROGRAM_PATH[
    all_missing
  ] <- NA_character_
}

# ------------------------------------------------------------
# 5. Keep one pathway record per student
# ------------------------------------------------------------

path_keep <- path_raw %>%
  dplyr::select(
    CNT,
    CNTSTUID,
    dplyr::any_of(
      c(
        "GRADE_PATH",
        "PROGRAM_PATH"
      )
    )
  ) %>%
  dplyr::distinct(
    CNT,
    CNTSTUID,
    .keep_all = TRUE
  )

# ------------------------------------------------------------
# 6. Merge pathway information into analytical data
# ------------------------------------------------------------

dat_path <- dat %>%
  dplyr::left_join(
    path_keep,
    by = c(
      "CNT",
      "CNTSTUID"
    )
  )

# ------------------------------------------------------------
# 7. Helper:
# Collapse sparse categories
# ------------------------------------------------------------

collapse_rare <- function(
    x,
    min_n
) {

  x <- as.character(x)

  tab <- table(
    x,
    useNA = "no"
  )

  rare <- names(
    tab[
      tab < min_n
    ]
  )

  x[
    !is.na(x) &
      x %in% rare
  ] <- "OTHER"

  factor(x)
}

# ------------------------------------------------------------
# 8. Outcome specifications
# ------------------------------------------------------------

pathway_specs <- list(

  CT = list(
    outcome = CT_Z,
    benchmark = NULL
  ),

  REL_MATH = list(
    outcome = CT_Z,
    benchmark = MATH_Z
  ),

  REL_READ = list(
    outcome = CT_Z,
    benchmark = READ_Z
  )
)

# ------------------------------------------------------------
# 9. Separate pathway specifications
# ------------------------------------------------------------

pathway_adjustments <- list(

  grade = list(
    variable = "GRADE_PATH",
    adjusted_stage = "grade_adjusted"
  ),

  programme = list(
    variable = "PROGRAM_PATH",
    adjusted_stage = "programme_adjusted"
  )
)

# ============================================================
# 10. SYSTEM-LEVEL MODELS
# ============================================================

for (spec_name in names(pathway_specs)) {

  spec <- pathway_specs[[spec_name]]

  for (sys in PRIMARY_SYSTEMS) {

    d0 <- dat_path %>%
      dplyr::filter(
        CNT == sys
      )

    for (adjustment_name in names(pathway_adjustments)) {

      adj_spec <- pathway_adjustments[[adjustment_name]]

      path_var <- adj_spec$variable
      adjusted_stage <- adj_spec$adjusted_stage

      # ------------------------------------------------------
      # Is this pathway variable available in this system?
      # ------------------------------------------------------

      path_available <- (
        path_var %in% names(d0) &&
          sum(
            !is.na(
              d0[[path_var]]
            )
          ) >= MIN_SYSTEM_N &&
          dplyr::n_distinct(
            d0[[path_var]],
            na.rm = TRUE
          ) >= 2
      )

      pathway_availability_rows[[
        paste(
          spec_name,
          sys,
          adjustment_name,
          sep = "__"
        )
      ]] <- tibble::tibble(
        outcome_spec = spec_name,
        CNT = sys,
        adjustment = adjustment_name,
        pathway_variable = path_var,
        available = path_available
      )

      if (!path_available) {
        next
      }

      # ------------------------------------------------------
      # Exact sample required ONLY for this pathway variable.
      # ------------------------------------------------------

      required <- c(
        "PE_days",
        CONTROLS,
        path_var,
        spec$outcome,
        spec$benchmark
      )

      smp <- build_exact_sample(
        dat_path,
        system = sys,
        required_vars = required
      )

      d <- smp$data

      if (
        !identical(
          smp$diagnostics$status[1],
          "OK"
        )
      ) {
        next
      }

      # ------------------------------------------------------
      # Collapse rare pathway categories after sample selection
      # ------------------------------------------------------

      d[[path_var]] <- collapse_rare(
        d[[path_var]],
        MIN_PROGRAM_CATEGORY_N
      )

      d <- droplevels(d)

      if (
        dplyr::n_distinct(
          d[[path_var]],
          na.rm = TRUE
        ) < 2
      ) {
        next
      }

      # ------------------------------------------------------
      # Core RHS
      # ------------------------------------------------------

      rhs_core_parts <- c(
        "PE_days",
        CONTROLS
      )

      if (!is.null(spec$benchmark)) {

        rhs_core_parts <- c(
          "PE_days",
          "BENCH",
          "I(BENCH^2)",
          "I(BENCH^3)",
          CONTROLS
        )
      }

      rhs_base <- paste(
        rhs_core_parts,
        collapse = " + "
      )

      rhs_adj <- paste(
        c(
          rhs_core_parts,
          path_var
        ),
        collapse = " + "
      )

      # ------------------------------------------------------
      # 10A. SAME-SAMPLE BASELINE
      # ------------------------------------------------------

      pooled_base <- fit_pv_full(
        df = d,
        outcome_cols = spec$outcome,
        rhs = rhs_base,
        benchmark_cols = spec$benchmark
      )

      base_est <- extract_terms(
        pooled_base,
        "PE_days"
      ) %>%
        dplyr::mutate(
          outcome_spec = spec_name,
          CNT = sys,
          adjustment = adjustment_name,
          pathway_variable = path_var,
          stage = "same_sample_baseline",
          model_rhs = rhs_base,
          n_students = nrow(d),
          n_schools = smp$diagnostics$n_schools[1],
          .before = 1
        )

      pathway_system_rows[[
        paste(
          spec_name,
          sys,
          adjustment_name,
          "baseline",
          sep = "__"
        )
      ]] <- base_est

      # ------------------------------------------------------
      # 10B. PATHWAY-ADJUSTED MODEL
      # ------------------------------------------------------

      pooled_adj <- fit_pv_full(
        df = d,
        outcome_cols = spec$outcome,
        rhs = rhs_adj,
        benchmark_cols = spec$benchmark
      )

      adj_est <- extract_terms(
        pooled_adj,
        "PE_days"
      ) %>%
        dplyr::mutate(
          outcome_spec = spec_name,
          CNT = sys,
          adjustment = adjustment_name,
          pathway_variable = path_var,
          stage = adjusted_stage,
          model_rhs = rhs_adj,
          n_students = nrow(d),
          n_schools = smp$diagnostics$n_schools[1],
          .before = 1
        )

      pathway_system_rows[[
        paste(
          spec_name,
          sys,
          adjustment_name,
          "adjusted",
          sep = "__"
        )
      ]] <- adj_est

      cat(
        "R5A OK: ",
        spec_name,
        " / ",
        sys,
        " / ",
        adjustment_name,
        " / N=",
        nrow(d),
        "\n",
        sep = ""
      )
    }
  }
}

# ============================================================
# 11. COMBINE SYSTEM RESULTS
# ============================================================

pathway_availability <- dplyr::bind_rows(
  pathway_availability_rows
)

pathway_system <- dplyr::bind_rows(
  pathway_system_rows
)

readr::write_csv(
  pathway_availability,
  file.path(
    TABLE_DIR,
    "S5_01_grade_programme_availability.csv"
  )
)

readr::write_csv(
  pathway_system,
  file.path(
    TABLE_DIR,
    "S5_02_PE_pathway_system_estimates.csv"
  )
)

# ============================================================
# 12. PAIRWISE SAME-SYSTEM META-ANALYSIS
# ============================================================

if (nrow(pathway_system) > 0) {

  pathway_meta_rows <- list()
  pathway_compare_rows <- list()

  meta_index <- 1L

  for (
    outcome_now in unique(
      pathway_system$outcome_spec
    )
  ) {

    for (
      adjustment_now in unique(
        pathway_system$adjustment
      )
    ) {

      if (adjustment_now == "grade") {

        adjusted_stage_now <- "grade_adjusted"

      } else if (adjustment_now == "programme") {

        adjusted_stage_now <- "programme_adjusted"

      } else {

        next
      }

      # ------------------------------------------------------
      # Systems with an adjusted estimate
      # ------------------------------------------------------

      adjusted_systems <-
        pathway_system %>%
        dplyr::filter(
          outcome_spec == outcome_now,
          adjustment == adjustment_now,
          stage == adjusted_stage_now
        ) %>%
        dplyr::distinct(CNT) %>%
        dplyr::pull(CNT)

      if (length(adjusted_systems) == 0) {
        next
      }

      # ------------------------------------------------------
      # Matching baseline
      # ------------------------------------------------------

      dd_base <-
        pathway_system %>%
        dplyr::filter(
          outcome_spec == outcome_now,
          adjustment == adjustment_now,
          stage == "same_sample_baseline",
          CNT %in% adjusted_systems
        )

      dd_adj <-
        pathway_system %>%
        dplyr::filter(
          outcome_spec == outcome_now,
          adjustment == adjustment_now,
          stage == adjusted_stage_now,
          CNT %in% adjusted_systems
        )

      common_systems <- intersect(
        dd_base$CNT,
        dd_adj$CNT
      )

      if (length(common_systems) == 0) {
        next
      }

      dd_base <- dd_base %>%
        dplyr::filter(
          CNT %in% common_systems
        )

      dd_adj <- dd_adj %>%
        dplyr::filter(
          CNT %in% common_systems
        )

      # ------------------------------------------------------
      # 12A. Baseline meta-analysis
      # ------------------------------------------------------

      meta_base <- meta_one(
        df = dd_base,
        model_id = paste(
          "PE_PATH",
          outcome_now,
          adjustment_now,
          "BASELINE",
          sep = "__"
        ),
        term_value = "PE_days"
      ) %>%
        dplyr::mutate(
          outcome_spec = outcome_now,
          adjustment = adjustment_now,
          stage = "same_sample_baseline",
          k_common_systems = length(common_systems),
          systems = paste(
            sort(common_systems),
            collapse = "+"
          ),
          .before = 1
        )

      # ------------------------------------------------------
      # 12B. Adjusted meta-analysis
      # ------------------------------------------------------

      meta_adj <- meta_one(
        df = dd_adj,
        model_id = paste(
          "PE_PATH",
          outcome_now,
          adjustment_now,
          "ADJUSTED",
          sep = "__"
        ),
        term_value = "PE_days"
      ) %>%
        dplyr::mutate(
          outcome_spec = outcome_now,
          adjustment = adjustment_now,
          stage = adjusted_stage_now,
          k_common_systems = length(common_systems),
          systems = paste(
            sort(common_systems),
            collapse = "+"
          ),
          .before = 1
        )

      pathway_meta_rows[[
        paste0(
          meta_index,
          "_baseline"
        )
      ]] <- meta_base

      pathway_meta_rows[[
        paste0(
          meta_index,
          "_adjusted"
        )
      ]] <- meta_adj

      # ------------------------------------------------------
      # 12C. Descriptive attenuation/change
      # ------------------------------------------------------

      pathway_compare_rows[[
        as.character(meta_index)
      ]] <- tibble::tibble(
        outcome_spec = outcome_now,
        adjustment = adjustment_now,
        k_common_systems = length(common_systems),
        systems = paste(
          sort(common_systems),
          collapse = "+"
        ),

        baseline_estimate =
          meta_base$estimate[1],

        baseline_ci_low =
          meta_base$ci_low[1],

        baseline_ci_high =
          meta_base$ci_high[1],

        adjusted_estimate =
          meta_adj$estimate[1],

        adjusted_ci_low =
          meta_adj$ci_low[1],

        adjusted_ci_high =
          meta_adj$ci_high[1],

        adjusted_minus_baseline =
          meta_adj$estimate[1] -
          meta_base$estimate[1],

        absolute_change =
          abs(
            meta_adj$estimate[1] -
            meta_base$estimate[1]
          ),

        proportional_change =
          dplyr::if_else(
            is.finite(
              meta_base$estimate[1]
            ) &&
              abs(
                meta_base$estimate[1]
              ) > 1e-12,

            (
              meta_adj$estimate[1] -
              meta_base$estimate[1]
            ) /
              abs(
                meta_base$estimate[1]
              ),

            NA_real_
          )
      )

      meta_index <- meta_index + 1L
    }
  }

  pathway_meta <- dplyr::bind_rows(
    pathway_meta_rows
  )

  pathway_compare <- dplyr::bind_rows(
    pathway_compare_rows
  )

  readr::write_csv(
    pathway_meta,
    file.path(
      TABLE_DIR,
      "S5_03_PE_pathway_meta.csv"
    )
  )

  readr::write_csv(
    pathway_compare,
    file.path(
      TABLE_DIR,
      "S5_04_PE_pathway_same_sample_comparison.csv"
    )
  )
}

# ============================================================
# 13. FINAL CONSOLE SUMMARY
# ============================================================

cat(
  "\n============================================================\n",
  "R5A COMPLETE\n",
  "============================================================\n",
  sep = ""
)

cat(
  "\nAvailability rows: ",
  nrow(pathway_availability),
  "\n",
  sep = ""
)

cat(
  "System-level estimate rows: ",
  nrow(pathway_system),
  "\n",
  sep = ""
)

if (exists("pathway_meta")) {

  cat(
    "Meta-analysis rows: ",
    nrow(pathway_meta),
    "\n",
    sep = ""
  )
}

if (exists("pathway_compare")) {

  cat(
    "Paired comparison rows: ",
    nrow(pathway_compare),
    "\n",
    sep = ""
  )
}

cat(
  "\nOutput files:\n",
  "  S5_01_grade_programme_availability.csv\n",
  "  S5_02_PE_pathway_system_estimates.csv\n",
  "  S5_03_PE_pathway_meta.csv\n",
  "  S5_04_PE_pathway_same_sample_comparison.csv\n",
  sep = ""
)
