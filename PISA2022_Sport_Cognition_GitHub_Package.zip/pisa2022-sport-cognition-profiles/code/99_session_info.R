# Save the R session information used for the final analysis.
# Run this script after loading the same project environment used for the manuscript.

dir.create("session_info", showWarnings = FALSE, recursive = TRUE)

sink(file.path("session_info", "sessionInfo.txt"))
print(sessionInfo())
sink()

if (requireNamespace("renv", quietly = TRUE)) {
  message("renv is installed. Consider running renv::snapshot() for a package lockfile.")
}
